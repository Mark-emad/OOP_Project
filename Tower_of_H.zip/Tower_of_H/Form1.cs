using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tower_of_H
{
    
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public int speed = 1600;
        public int num = 0;
        public Panel[] arr;
        public Panel[] arr_satck;
        public Label x = new Label();
        Stack myStack = new Stack(20);
        Label[] myarr = new Label[20];
        int xi = 0;
        int co = 0;
        public  void towerOfHanoi(int n, char from_rod,
                           char to_rod, char m_rod)
        {
            myarr[co] = new Label();
            myarr[co].Text = $"towerOfHanoi( {n} , {from_rod}  , {to_rod}  , {m_rod})  ";
            myarr[co].Location = new Point(1000, 476 - xi);
            myarr[co].Size = new Size(170, 60);
            xi += 30;
           
            
            this.Controls.Add(myarr[co]); myarr[co].BringToFront();
            myStack.Push(myarr[co]);
 co++;
            
            if (n == 0)
            {
                Thread.Sleep(speed);

                myStack.Pop();
                xi -= 20;
                return;
            }
            towerOfHanoi(n - 1, from_rod, m_rod, to_rod);

            if(to_rod == 'B')
            arr[n].Location = new Point(434 + (num - n )*10, 395 - (num - n) * 20);
            if (to_rod == 'C')
                arr[n].Location = new Point(776 + (num - n) * 10, 395 - (num - n) * 20);
            if(to_rod == 'A') arr[n].Location = new Point(100 + (num - n) * 10, 395 - (num - n) * 20);
            //  Console.WriteLine("Move disk " + n + " from rod " + from_rod + " to rod " + to_rod);
            towerOfHanoi(n - 1, m_rod, to_rod, from_rod);
        }
        
        private void button1_Click(object sender, EventArgs e)
        {

           
            string s = comboBox1.Text;
            if (s == "5x") { speed = 0; }else if (s == "4x") { speed = 400; } else if (s == "3x") { speed = 800; } else if (s == "2x") { speed = 1200; } else if(s == "1x") { speed = 1600; } else if(s== "0.5x") { speed = 2000; }
            for (int i = num - 1; i >= 0; i--)
            {

               
                this.Controls.Remove(arr[i]); 
            }
            num = 1;
            num += int.Parse(txtb1.Text);
            if(num > 13 || num <= 1)
            {
                num = 0;
                MessageBox.Show("Please enter a valid number from 1 to 13");
                return;
                
            }
            arr = new Panel[num];
            
            arr_satck = new Panel[num];

 
            int xo = 0, yo = 0;

            for(int i = num  -1 ; i != 0; i--)
            {
                
                arr[i] = new Panel();
                arr[i].BorderStyle = BorderStyle.FixedSingle;
                arr[i].Location = new Point(100 + xo/2, 395 - yo );
                arr[i].BackColor = Color.White;
                arr[i].Size = new Size(264 - xo, 17 );
           
               
                //arr[i].Focus();
                yo += 20;
                xo += 20;

                this.Controls.Add(arr[i]);arr[i].BringToFront();
            }
            towerOfHanoi(num -1 , 'A', 'C', 'B');
       
            
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel6_ForeColorChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = num - 1; i != 0; i--)
            {


                this.Controls.Remove(arr[i]);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.

        }

        private void label1_Click(object sender, EventArgs e)
        {
            

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}