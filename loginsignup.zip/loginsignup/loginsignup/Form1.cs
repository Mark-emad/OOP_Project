using System.IO;
namespace loginsignup
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.ActiveControl = TxtUser; 
            TxtUser.Focus();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user = TxtUser.Text;
            string filepath = @"C:\Users\h\source\repos\loginsignup\loginsignup";
            string pass = TxtPass.Text;
            List<string> lines = File.ReadAllLines(filepath).ToList();//return an array of strings
            foreach (string line in lines)
            {
                Console.WriteLine(line);
            }//for printing
            lines.Add("maroka,12345");//for adding
            File.WriteAllLines(filepath, lines);//for adding also

            if (user == "admin" && pass == "admin")
            {
                MessageBox.Show("You Are In");
            }
            else
            {
                MessageBox.Show("Invalid Username Or Password!");
            }
            TxtUser.Clear();
            TxtPass.Clear();
        }

        private void TxtUser_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                TxtPass.Focus();
            }
        }

        private void TxtPass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.Select();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TxtUser.BackColor = Color.White;
            TxtPass.BackColor = Color.White;
            TxtUser.BorderStyle= BorderStyle.None;
            TxtPass.BorderStyle = BorderStyle.None;
            Panel p1=new Panel();
            p1.Size= new Size(TxtUser.Width,1);
            p1.BackColor = Color.Red;
            Panel p2 = new Panel();
            p2.Size = new Size(TxtPass.Width, 1);
            p2.BackColor = Color.Red;
            this.Controls.Add(p1);
            this.Controls.Add(p2);
            p1.Location= new Point(TxtUser.Location.X,TxtUser.Location.Y+TxtUser.Height);
            p2.Location = new Point(TxtPass.Location.X, TxtPass.Location.Y + TxtPass.Height);

        }

        private void TxtUser_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (showpass.Checked)
            {
                TxtPass.PasswordChar = '\0';
            }
            if (showpass.Checked==false)
            {
                TxtPass.PasswordChar = '*';
            }
        }
    }
}